module.exports = {
  "extends": "../.eslintrc.js",
  "parserOptions": {
      "ecmaVersion": 6,
      "sourceType": 'module',
  }
}
