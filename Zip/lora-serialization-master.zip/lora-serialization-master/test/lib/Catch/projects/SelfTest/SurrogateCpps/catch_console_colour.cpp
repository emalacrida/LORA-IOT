// This file is only here to verify (to the extent possible) the self sufficiency of the header
#include "internal/catch_suppress_warnings.h"
#include "internal/catch_console_colour.hpp"
